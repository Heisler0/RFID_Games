import pygame, inputbox
from pygame import *
from pygame.mixer import Sound
from time import sleep

pygame.init()
pygame.mixer.init()

# Window Size
size = (448, 388)

# Window Colors
red = (255, 0, 0)
green = (0, 255, 0)

# Display the window
window = display.set_mode(size)
display.set_caption("Cardlock")

# Set up sound variables
lock = Sound("lock.wav")
unlock = Sound("unlock.wav")
airhorn = Sound("airhorn.wav")

# My Keycard ID Number
keycard = "012345"

while True:
    window.fill(green)
    inputbox.ask(window, "Press enter to lock")
    display.toggle_fullscreen()
    lock.play()
    locked = True

    while locked:
        window.fill(red)
        entry = inputbox.ask(window, "Locked")
        if entry == keycard:
            locked = False
            unlock.play()
            display.toggle_fullscreen()
        else:
            airhorn.play()
